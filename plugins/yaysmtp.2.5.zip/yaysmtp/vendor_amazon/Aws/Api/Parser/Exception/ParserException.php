<?php

namespace YaySMTP\Aws3\Aws\Api\Parser\Exception;

class ParserException extends \RuntimeException
{
}
