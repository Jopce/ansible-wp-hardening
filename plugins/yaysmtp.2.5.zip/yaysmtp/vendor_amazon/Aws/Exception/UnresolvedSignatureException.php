<?php

namespace YaySMTP\Aws3\Aws\Exception;

class UnresolvedSignatureException extends \RuntimeException {
}
