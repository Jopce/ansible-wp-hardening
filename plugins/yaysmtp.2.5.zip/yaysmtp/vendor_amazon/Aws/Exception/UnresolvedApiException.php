<?php

namespace YaySMTP\Aws3\Aws\Exception;

class UnresolvedApiException extends \RuntimeException
{
}
