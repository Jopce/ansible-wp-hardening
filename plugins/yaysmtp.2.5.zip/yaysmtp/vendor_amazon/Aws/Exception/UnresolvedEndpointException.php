<?php

namespace YaySMTP\Aws3\Aws\Exception;

class UnresolvedEndpointException extends \RuntimeException
{
}
