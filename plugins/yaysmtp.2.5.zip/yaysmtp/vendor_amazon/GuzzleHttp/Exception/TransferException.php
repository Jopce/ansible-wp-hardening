<?php

namespace YaySMTP\Aws3\GuzzleHttp\Exception;

class TransferException extends \RuntimeException implements \YaySMTP\Aws3\GuzzleHttp\Exception\GuzzleException
{
}
