<?php

namespace YaySMTP\Aws3\GuzzleHttp\Exception;

/**
 * Exception when a client error is encountered (4xx codes)
 */
class ClientException extends \YaySMTP\Aws3\GuzzleHttp\Exception\BadResponseException
{
}
