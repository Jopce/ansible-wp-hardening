<?php

namespace YaySMTP\Aws3\GuzzleHttp\Exception;

class TooManyRedirectsException extends \YaySMTP\Aws3\GuzzleHttp\Exception\RequestException
{
}
