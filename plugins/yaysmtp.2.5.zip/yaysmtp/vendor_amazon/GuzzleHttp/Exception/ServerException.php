<?php

namespace YaySMTP\Aws3\GuzzleHttp\Exception;

/**
 * Exception when a server error is encountered (5xx codes)
 */
class ServerException extends \YaySMTP\Aws3\GuzzleHttp\Exception\BadResponseException
{
}
